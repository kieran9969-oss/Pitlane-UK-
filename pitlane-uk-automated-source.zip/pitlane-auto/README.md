# PITLANE UK automated event source

This is a runnable, no-dependency Python iCalendar aggregator, with daily GitHub Actions scheduling.

## Start
1. Create a GitHub repository and upload this folder's contents to its root.
2. Obtain **permission** to ingest each provider's feed. Add the real `.ics` URL in `sources.json` and set `enabled` to `true`. Do not assume a publicly visible calendar permits copying or republishing.
3. Under repository Settings > Actions > General, allow the workflow to read/write repository contents if needed.
4. Run `python sync.py` locally or trigger **Refresh UK events** in GitHub Actions. Daily refresh runs at 05:20 UTC (GitHub scheduling may be delayed).
5. Publish `data/events.json` from the repository via your own website or API. Point the PITLANE UK front end at this JSON endpoint. Set CORS if hosting separately.
6. Add verified manual events to `data/manual-events.json` using fields: `name`, `date` (`YYYY-MM-DD`), `venue`, `official_url`, optionally `ticket_url`, `region`, `category`, `status`, `organiser`.

## Important limitations
- The starter configuration has **no enabled external feeds**. You must add authorised source feeds for real automatic imports.
- This does not import HTML pages, scrape other sites, or connect to an API without documented access.
- Events imported from ICS are **Unverified**, not confirmed. `last_checked` records the successful import time, not the organiser's verification time.
- Duplicates are matched by normalised name + start date + venue; near-duplicates may still require manual review.
- Event cancellations and date changes may need human verification.
- The sync retains stale previous entries if a source fails, marking them accordingly.
- GitHub Actions must be enabled and the repository accessible for the job to run; nothing is deployed or scheduled by merely downloading this package.
